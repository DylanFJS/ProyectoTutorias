import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dart:io';
import 'package:path_provider/path_provider.dart'; // Asegúrate de agregar este paquete en pubspec.yaml

void _createNotification(String studentUsername, String message) async {
  final directory = await getApplicationDocumentsDirectory();
  final path = '${directory.path}/notifications.csv';
  final file = File(path);

  List<List<dynamic>> rows = [];

  // Leer notificaciones existentes si el archivo ya existe
  if (await file.exists()) {
    final contents = await file.readAsString();
    rows = CsvToListConverter().convert(contents);
  }

  // Agregar la nueva notificación
  rows.add([studentUsername, message]);

  // Guardar las notificaciones actualizadas
  final csv = const ListToCsvConverter().convert(rows);
  await file.writeAsString(csv);
}




void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inicio de sesión',
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.yellow,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TutoUis'),
      ),
      body: Column(
        children: [
          // Agregar la imagen en la parte superior
          Image.asset(
            'assets/image.png',
            height: 300, // Ajusta la altura según tu necesidad
            width: 300, // Ocupa todo el ancho disponible
            fit: BoxFit.cover, // Ajusta la imagen para que cubra el contenedor
          ),
          LoginForm(),
        ],
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _selectedRole = 'Estudiante'; // Default role is Student

  void _showMessage(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Mensaje'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<List<Map<String, String?>>> _loadUserCredentials() async {
    final String csvString = await rootBundle.loadString('assets/users.csv');
    final List<List<dynamic>> csvUsers = CsvToListConverter().convert(csvString);
    return csvUsers.map((user) => {
      'username': user[0].toString(),
      'password': user[1].toString(),
      'role': user[2]?.toString(), // Handle nullable value here
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: _usernameController,
            decoration: InputDecoration(
              labelText: 'Nombre de usuario',
            ),
          ),
          SizedBox(height: 20.0),
          TextField(
            controller: _passwordController,
            decoration: InputDecoration(
              labelText: 'Contraseña',
            ),
            obscureText: true,
          ),
          SizedBox(height: 20.0),
          DropdownButtonFormField<String>(
            value: _selectedRole,
            onChanged: (newValue) {
              setState(() {
                _selectedRole = newValue!;
              });
            },
            items: ['Estudiante', 'Tutor']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            decoration: InputDecoration(
              labelText: 'Seleccione su rango',
            ),
          ),
          SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () async {
              String username = _usernameController.text;
              String password = _passwordController.text;

              List<Map<String, String?>> users = await _loadUserCredentials();
              bool credentialsMatch = false;
              for (var user in users) {
                if (user['username'] == username && user['password'] == password) {
                  credentialsMatch = true;
                  _selectedRole = user['role'] ?? 'Estudiante'; // Handle potential null value
                  break;
                }
              }

              if (credentialsMatch) {
                if (_selectedRole == 'Estudiante') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => StudentMenuPage()),
                  );
                } else if (_selectedRole == 'Tutor') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TutorMenuPage()),
                  );
                }
              } else {
                _showMessage(context, 'Nombre de usuario o contraseña incorrectos');
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _selectedRole == 'Estudiante' ? Colors.blue : Colors.green,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
            ),
            child: Text(
              'Iniciar sesión',
              style: TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class StudentMenuPage extends StatefulWidget {
  @override
  _StudentMenuPageState createState() => _StudentMenuPageState();
}

class _StudentMenuPageState extends State<StudentMenuPage> {
  List<Chat> _chats = [];
  List<Notification> _notifications = [];

  @override
  void initState() {
    super.initState();
    _loadChats();
    _loadNotifications();
  }

  void _loadNotifications() async {
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/notifications.csv';
    final file = File(path);

    if (await file.exists()) {
      final contents = await file.readAsString();
      List<List<dynamic>> rows = CsvToListConverter().convert(contents);
      setState(() {
        _notifications = rows.map((row) => Notification(row[0], row[1])).toList();
      });
    }
  }

  void _loadChats() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? chatNames = prefs.getStringList('chatNames');
    if (chatNames != null) {
      setState(() {
        _chats = chatNames.map((chatName) {
          String groupName = chatName;
          List<String>? messages = prefs.getStringList('$groupName-messages');
          int currentParticipants = prefs.getInt('$groupName-currentParticipants') ?? 0;
          int maxParticipants = prefs.getInt('$groupName-maxParticipants') ?? 1;
          String description = prefs.getString('$groupName-description') ?? '';
          return Chat(groupName, messages ?? [], currentParticipants, maxParticipants, description);
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    List<Notification> studentNotifications = _notifications.where((notification) => notification.studentUsername == 'studentUsername').toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Menú Estudiante'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navegar a la página de perfil
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 65),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
              ),
              child: const Text(
                'Ver perfil',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => GroupListPage(chats: _chats)),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 65),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
              ),
              child: const Text(
                'Menú de solicitudes',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),
            if (studentNotifications.isNotEmpty) ...[
              Text('Notificaciones:'),
              for (var notification in studentNotifications)
                ListTile(
                  title: Text(notification.message),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class TutorMenuPage extends StatefulWidget {
  @override
  _TutorMenuPageState createState() => _TutorMenuPageState();
}

class _TutorMenuPageState extends State<TutorMenuPage> {
  List<Chat> _chats = [];

  @override
  void initState() {
    super.initState();
    _loadChats();
  }

  void _loadChats() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? chatNames = prefs.getStringList('chatNames');
    if (chatNames != null) {
      setState(() {
        _chats = chatNames.map((chatName) {
          String groupName = chatName;
          List<String>? messages = prefs.getStringList('$groupName-messages');
          int currentParticipants = prefs.getInt('$groupName-currentParticipants') ?? 0;
          int maxParticipants = prefs.getInt('$groupName-maxParticipants') ?? 1;
          String description = prefs.getString('$groupName-description') ?? '';
          return Chat(groupName, messages ?? [], currentParticipants, maxParticipants, description);
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menú Tutor'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navegar a la página de perfil
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 65),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
              ),
              child: const Text(
                'Ver perfil',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => _CreateChatDialog(),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 65),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
              ),
              child: const Text(
                'Crear Nuevo Grupo',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => GroupListPage(chats: _chats)),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 65),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
              ),
              child: const Text(
                'Ver Grupos',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CreateChatDialog extends StatefulWidget {
  @override
  _CreateChatDialogState createState() => _CreateChatDialogState();
}

class _CreateChatDialogState extends State<_CreateChatDialog> {
  String newGroupName = '';
  int _selectedStudentCount = 1; // Default selected count
  String _selectedSubject = 'Calculo I'; // Default selected subject

  void _saveChat(Chat chat) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> chatNames = prefs.getStringList('chatNames') ?? [];
    if (!chatNames.contains(chat.groupName)) {
      chatNames.add(chat.groupName);
      await prefs.setStringList('chatNames', chatNames);
    }
    await prefs.setStringList('${chat.groupName}-messages', chat.messages);
    await prefs.setInt('${chat.groupName}-currentParticipants', chat.currentParticipants);
    await prefs.setInt('${chat.groupName}-maxParticipants', chat.maxParticipants);
    await prefs.setString('${chat.groupName}-description', chat.description);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Crear Nuevo Grupo'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            decoration: InputDecoration(labelText: 'Nombre del Grupo'),
            onChanged: (value) {
              setState(() {
                newGroupName = value;
              });
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Cantidad de Estudiantes:'),
              DropdownButton<int>(
                value: _selectedStudentCount,
                onChanged: (value) {
                  setState(() {
                    _selectedStudentCount = value!;
                  });
                },
                items: <int>[1, 2, 3, 4, 5].map<DropdownMenuItem<int>>((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Materia:'),
              DropdownButton<String>(
                value: _selectedSubject,
                onChanged: (value) {
                  setState(() {
                    _selectedSubject = value!;
                  });
                },
                items: <String>[
                  'Calculo I',
                  'Fisica II',
                  'Programación Avanzada',
                  'Historia'
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ],
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        TextButton(
          onPressed: () {
            Chat newChat = Chat(newGroupName, [], 0, _selectedStudentCount, 'Materia: $_selectedSubject');
            _saveChat(newChat);

            // Generar notificaciones para todos los estudiantes
            List<Map<String, String?>> users = await _loadUserCredentials();
            for (var user in users) {
              if (user['role'] == 'Estudiante') {
                _createNotification(user['username']!, 'Se ha creado un nuevo grupo: $newGroupName en la materia $_selectedSubject');
              }
            }

            Navigator.of(context).pop();
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => GroupListPage(chats: [])), // Initialize with empty list
            );
          },
          child: Text('Crear'),
        ),

      ],
    );
  }
}

class GroupListPage extends StatelessWidget {
  final List<Chat> chats;

  const GroupListPage({Key? key, required this.chats}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Grupos'),
      ),
      body: ListView.builder(
        itemCount: chats.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(chats[index].groupName),
            onTap: () {
              // Navegar a la página del grupo específico
            },
          );
        },
      ),
    );
  }
}

class Chat {
  final String groupName;
  final List<String> messages;
  final int currentParticipants;
  final int maxParticipants;
  final String description;

  Chat(this.groupName, this.messages, this.currentParticipants, this.maxParticipants, this.description);
}

class Notification {
  final String studentUsername;
  final String message;

  Notification(this.studentUsername, this.message);
}
