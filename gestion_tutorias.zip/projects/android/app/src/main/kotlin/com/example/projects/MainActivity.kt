package com.example.projects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
